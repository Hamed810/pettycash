# Pettycash UI Prototype — English Sheets + Modal v2

This folder is a **review-only** fork of the user-supplied Manus prototype, not a production implementation. The original ZIP was left untouched. This version adds an English-first purchaser Sheets List with two financial figures, row-to-modal workspace behavior, a shared sheet/transaction workspace, and unsaved-changes confirmation. It contains only synthetic in-memory data.

## Open

Serve the folder: `python3 -m http.server 3000`, then open `http://localhost:3000/?page=sheets&lang=en&theme=light`. Use `theme=dark` for dark mode, or `&sheet=PC-2401` for a direct view.

Click **October office supplies** for an editable Open sheet, choose **Edit sheet**, change the title, and press close to test the unsaved changes choices. Click **Field visit — Q4** to preview correction, and **Team workshop** for read-only Finance review. The original dashboard and create form remain available as secondary prototype pages.

Screenshots generated from this version are in `exports-v2/`. See `DESIGN-V2.md` for the approved decisions, important limitations, and integration tasks. Existing Persian resources are retained, but **Persian design is paused**; new modal and financial-list interactions have been designed/tested only for English LTR.

No backend, API, Pettycash repository, or real financial data is used.
