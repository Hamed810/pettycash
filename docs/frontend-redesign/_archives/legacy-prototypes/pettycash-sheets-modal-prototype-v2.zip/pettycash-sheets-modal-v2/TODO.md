# Pettycash design refinement checklist

- [x] Refine only Dashboard, Sheets List, and Create/Edit Sheet; do not explore beyond these pages.
- [x] Use English LTR as the master design and provide an equally high-quality Persian RTL adaptation.
- [x] Remove prototype debugging controls, UI prototype labels, mock workspace/account controls, and duplicated mobile content from final design surfaces.
- [x] Replace unsupported sheet-name search with status, currency, date-from, and date-to filters; show creator scope as informative.
- [x] Preserve financial and audit-facing list information and all existing row actions.
- [x] Show zero/one/many account branches; derive currency from the selected account; show balance only for the selected account; retain the valid zero-account default-provisioning path.
- [x] Use role-sensitive existing Dashboard workflow buckets and quick links without adding fake statistics, charts, or business workflows.
- [x] Provide clean portable source, PNG exports, component/token documentation, and a change log.
- [x] Label unresolved behavior assumptions and stop for product-owner approval.
