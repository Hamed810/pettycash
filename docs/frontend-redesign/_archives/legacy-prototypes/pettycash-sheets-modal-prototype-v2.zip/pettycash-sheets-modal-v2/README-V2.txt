Pettycash Sheets prototype v2 — English LTR only
Open index.html (or serve with python3 -m http.server 3000)
Start at ?page=sheets&lang=en&theme=light
Choose a row → inspect detail modal. Open row → Edit → change title → Close to see unsaved changes confirmation.
Explore Finance review row (read-only), Correction row (correct transaction), responsive/mobile layout, dark ?theme=dark.
See DESIGN-V2.md for assumptions and production limitations.
