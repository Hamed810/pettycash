# Pettycash design refinement change log

## 2026-10-17 — English-first review set

Refined the existing prototype rather than starting over. English LTR is now the master composition, with Persian RTL adapted using bidi-isolated money, IDs, and dates and mobile-safe reflow.

Removed the prototype debugging strip, UI prototype labels, workspace switcher, locale/theme controls, and demo account controls from the final design surface. The design does not recreate Nextcloud global UI.

Replaced the unsupported sheet-name search with the existing status, currency, date-from, and date-to facets. Creator is presented as an informative scope, not an editable filter. The sheet table now retains the workflow’s financial and audit-facing information: creator, currency, status, transaction count, active revision, current/submitted totals, latest effective outcome, stage-approved totals, key dates, and actions.

Refined Create/Edit Sheet to show zero-account, one-account, and many-account branches. Currency is inherited from the selected account, and a balance is shown only when an account is selected. The zero-account branch remains valid for the existing default-provisioning workflow. The duplicated mobile block was removed through one responsive row/card renderer.

Refined Dashboard to role-sensitive workflow buckets and quick links only. No new statistics, charts, balance claims, or business workflows were added.

## Unresolved behavior assumptions

The supplied design contract was not present in the active filesystem at refinement time. The implementation therefore follows the detailed task constraints and the inspected Pettycash Vue source, store, and API types as the binding sources.

The dashboard role shown is the existing purchaser role because the inspected sheet form and creator-scoped list are purchaser workflows. Exact server-side role visibility and the final dashboard metric labels remain subject to product-owner confirmation.

The date examples, amounts, IDs, names, and account labels are synthetic and are not intended as production records.

## 2026-10-18 — English purchaser Sheets List correction

Refined only the English LTR Sheets List. Existing Persian/RTL source and exports were preserved and were not regenerated.

The purchaser-scoped list now omits the Creator column on that surface because every listed row belongs to the authenticated purchaser. Creator remains in the shared synthetic data model and in the broader table renderer used by the dashboard/reusable views.

Row actions now follow the inspected Pettycash lifecycle rules: Open rows expose View, Edit, and Delete; Returned for correction exposes View and Correct; Finance review and Completed rows expose View only with a concise unavailable-state note. No unconditional Edit or Delete control remains on submitted, finance-review, or completed rows.

Synthetic records were aligned with their workflow state. Open has no submitted or stage-approved total; Returned for correction has a rejected amount and prior stage approvals; Finance review has manager and senior approvals with finance pending; Completed has all three stage approvals and a completion date.

### Unresolved permission questions

The source UI and comments establish status-based purchaser guards, but the final production capability matrix is still server-enforced. Product owners should confirm whether a purchaser may edit a returned row through the same route as an open row, whether a separate “Correct” label is preferred, and whether any authenticated purchaser capability can further restrict Open-row deletion. Manager and finance review queues are intentionally not represented as purchaser actions in this update.
