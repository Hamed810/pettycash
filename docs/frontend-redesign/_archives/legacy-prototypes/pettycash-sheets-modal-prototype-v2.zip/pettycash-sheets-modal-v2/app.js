const app = document.querySelector('#app')
const params = new URLSearchParams(location.search)
const state = {
  lang: params.get('lang') === 'fa' ? 'fa' : 'en',
  theme: params.get('theme') === 'dark' ? 'dark' : 'light',
  page: params.get('page') === 'dashboard' ? 'dashboard' : params.get('page') === 'create' ? 'create' : 'sheets',
  mode: params.get('mode') === 'edit' ? 'edit' : 'create',
  accountBranch: ['zero', 'one', 'many'].includes(params.get('accounts')) ? params.get('accounts') : 'many',
  formTitle: params.get('mode') === 'edit' ? 'October office supplies' : '',
  selectedAccount: params.get('account') || (params.get('accounts') === 'one' ? 'single' : ''),
  validation: false,
}

const copy = {
  en: {
    appName: 'Pettycash', dashboard: 'Dashboard', sheets: 'Sheets', createSheet: 'Create sheet', editSheet: 'Edit sheet', reviewQueue: 'Review queue', accounts: 'Accounts', reports: 'Reports', workspace: 'Workspace', support: 'Support',
    overview: 'Overview', dashboardSub: 'A role-aware view of sheets that need your attention.', sheetsSub: 'Review every sheet, its ownership, dates, totals, and approval outcomes.', createSub: 'Start a new petty-cash cycle with the fields used by the existing workflow.', editSub: 'Update the sheet title or account before continuing its existing workflow.', today: 'October 16, 2026', newSheet: 'New sheet', viewSheets: 'View sheets',
    purchaserView: 'Purchaser view', creatorScope: 'Creator scope', creatorScopeBody: 'Only sheets created by you are shown.', openSheets: 'Open sheets', awaitingReview: 'Awaiting review', correction: 'Needs correction', completed: 'Completed', openHint: 'Can still receive transactions', awaitingHint: 'Moving through approval stages', correctionHint: 'Returned to you for changes', completedHint: 'Finished approval outcome',
    quickLinks: 'Quick links', continueDraft: 'Continue an open sheet', continueDraftBody: 'Add or review transactions on a sheet that is still open.', reviewReturned: 'Review returned sheets', reviewReturnedBody: 'Open a sheet that needs purchaser correction.', createNew: 'Create a new sheet', recent: 'Recent sheets', recentBody: 'The latest sheets in your creator scope.',
    sheet: 'Sheet', owner: 'Creator', currency: 'Currency', status: 'Status', transactions: 'Transactions', activeRevision: 'Active revision', totals: 'Totals', latestOutcome: 'Latest effective outcome', stageApproved: 'Stage-approved totals', keyDates: 'Key dates', actions: 'Actions', view: 'View', edit: 'Edit', correct: 'Correct', delete: 'Delete', more: 'More', purchaserList: 'Only sheets created by you are shown', noEditDelete: 'Unavailable at this stage',
    open: 'Open', costCenter: 'Cost center review', senior: 'Senior review', finance: 'Finance review', completedApproved: 'Completed — approved', completedRejected: 'Completed — rejected', correctionStatus: 'Purchaser correction',
    current: 'Current', submitted: 'Submitted', approved: 'Approved', rejected: 'Rejected', pending: 'Pending', manager: 'Cost center', seniorShort: 'Senior', financeShort: 'Finance', created: 'Created', submittedAt: 'Submitted', completedAt: 'Completed', firstExpense: 'First expense', lastExpense: 'Last expense', noDate: '—',
    filters: 'Filters', statusFilter: 'Status', allStatuses: 'All statuses', currencyFilter: 'Currency', allCurrencies: 'All currencies', from: 'Date from', to: 'Date to', apply: 'Apply filters', reset: 'Reset', showing: 'Showing 4 sheets in your creator scope',
    details: 'Sheet details', title: 'Title', titlePlaceholder: 'e.g. October office supplies', account: 'Account', selectAccount: 'Select an account', accountBalance: 'Selected account balance', inheritedCurrency: 'Currency', inheritedHint: 'Inherited from the selected account', noAccounts: 'No petty-cash account is available.', noAccountsBody: 'The existing workflow can provision the default account when this form is submitted without an account selection.', oneAccount: 'One account is available and will be selected automatically.', manyAccounts: 'Choose one account to set the sheet currency.', cancel: 'Cancel', create: 'Create sheet', update: 'Update sheet', required: 'This field is required.', validationTitle: 'Check the form', validationBody: 'Add a title before continuing.', noBalance: 'Select an account to show its balance.',
    empty: 'No sheets found', emptyBody: 'Adjust the status, currency, or date filters, or create a new sheet.', errorTitle: 'Unable to load sheets', errorBody: 'The list could not be loaded in this preview.', retry: 'Try again', loading: 'Loading sheets', loadingBody: 'Preparing the current creator scope…',
  },
  fa: {
    appName: 'تنخواه', dashboard: 'داشبورد', sheets: 'برگه‌ها', createSheet: 'ایجاد برگه', editSheet: 'ویرایش برگه', reviewQueue: 'صف بررسی', accounts: 'حساب‌ها', reports: 'گزارش‌ها', workspace: 'فضای کاری', support: 'پشتیبانی', overview: 'نمای کلی', dashboardSub: 'نمایی متناسب با نقش از برگه‌هایی که به توجه شما نیاز دارند.', sheetsSub: 'همه برگه‌ها، مالکیت، تاریخ‌ها، جمع‌ها و نتایج تأیید را مرور کنید.', createSub: 'چرخه جدید تنخواه را با فیلدهای جریان کاری موجود شروع کنید.', editSub: 'پیش از ادامه جریان کاری موجود، عنوان یا حساب برگه را به‌روزرسانی کنید.', today: '۱۶ اکتبر ۲۰۲۶', newSheet: 'برگه جدید', viewSheets: 'مشاهده برگه‌ها', purchaserView: 'نمای خریدار', creatorScope: 'محدوده ایجادکننده', creatorScopeBody: 'فقط برگه‌های ایجادشده توسط شما نمایش داده می‌شوند.', openSheets: 'برگه‌های باز', awaitingReview: 'در انتظار بررسی', correction: 'نیازمند اصلاح', completed: 'تکمیل‌شده', openHint: 'هنوز امکان دریافت تراکنش دارد', awaitingHint: 'در حال عبور از مراحل تأیید', correctionHint: 'برای اصلاح به شما بازگشته', completedHint: 'نتیجه تأیید نهایی شده', quickLinks: 'پیوندهای سریع', continueDraft: 'ادامه یک برگه باز', continueDraftBody: 'تراکنش‌های یک برگه باز را بررسی یا تکمیل کنید.', reviewReturned: 'بررسی برگه‌های بازگشتی', reviewReturnedBody: 'برگه‌ای را که نیازمند اصلاح است باز کنید.', createNew: 'ایجاد برگه جدید', recent: 'برگه‌های اخیر', recentBody: 'آخرین برگه‌ها در محدوده ایجادکننده شما.', sheet: 'برگه', owner: 'ایجادکننده', currency: 'ارز', status: 'وضعیت', transactions: 'تراکنش', activeRevision: 'نسخه فعال', totals: 'جمع‌ها', latestOutcome: 'آخرین نتیجه مؤثر', stageApproved: 'جمع‌های تأیید مرحله‌ای', keyDates: 'تاریخ‌های کلیدی', actions: 'اقدامات', view: 'مشاهده', edit: 'ویرایش', delete: 'حذف', more: 'بیشتر', open: 'باز', costCenter: 'بررسی مرکز هزینه', senior: 'بررسی ارشد', finance: 'بررسی مالی', completedApproved: 'تکمیل‌شده — تأیید', completedRejected: 'تکمیل‌شده — رد', correctionStatus: 'اصلاح خریدار', current: 'جاری', submitted: 'ثبت‌شده', approved: 'تأییدشده', rejected: 'ردشده', pending: 'در انتظار', manager: 'مرکز هزینه', seniorShort: 'ارشد', financeShort: 'مالی', created: 'ایجاد', submittedAt: 'ثبت', completedAt: 'تکمیل', firstExpense: 'نخستین هزینه', lastExpense: 'آخرین هزینه', noDate: '—', filters: 'پالایه‌ها', statusFilter: 'وضعیت', allStatuses: 'همه وضعیت‌ها', currencyFilter: 'ارز', allCurrencies: 'همه ارزها', from: 'از تاریخ', to: 'تا تاریخ', apply: 'اعمال پالایه', reset: 'بازنشانی', showing: 'نمایش ۴ برگه در محدوده ایجادکننده شما', details: 'جزئیات برگه', title: 'عنوان', titlePlaceholder: 'مثلاً ملزومات اداری مهرماه', account: 'حساب', selectAccount: 'انتخاب حساب', accountBalance: 'موجودی حساب انتخاب‌شده', inheritedCurrency: 'ارز', inheritedHint: 'از حساب انتخاب‌شده به ارث می‌رسد', noAccounts: 'حساب تنخواهی در دسترس نیست.', noAccountsBody: 'اگر بدون انتخاب حساب ارسال شود، جریان کاری موجود می‌تواند حساب پیش‌فرض را ایجاد کند.', oneAccount: 'یک حساب موجود است و به‌صورت خودکار انتخاب می‌شود.', manyAccounts: 'برای تعیین ارز برگه، یک حساب انتخاب کنید.', cancel: 'انصراف', create: 'ایجاد برگه', update: 'به‌روزرسانی برگه', required: 'تکمیل این فیلد الزامی است.', validationTitle: 'فرم را بررسی کنید', validationBody: 'پیش از ادامه، عنوان را وارد کنید.', noBalance: 'برای نمایش موجودی، یک حساب انتخاب کنید.', empty: 'برگه‌ای پیدا نشد', emptyBody: 'پالایه‌های وضعیت، ارز یا تاریخ را تغییر دهید یا برگه جدیدی ایجاد کنید.', errorTitle: 'بارگذاری برگه‌ها ممکن نبود', errorBody: 'فهرست در این پیش‌نمایش بارگذاری نشد.', retry: 'تلاش مجدد', loading: 'در حال بارگذاری برگه‌ها', loadingBody: 'محدوده ایجادکننده فعلی آماده می‌شود…',
  }
}
const t = (key) => copy[state.lang][key] || copy.en[key] || key
const icon = (name) => { const p = { dashboard:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>', sheets:'<path d="M6 3.5h9l3 3V20.5H6z"/><path d="M15 3.5v4h3M9 12h6M9 16h6"/>', review:'<path d="M4 5.5h16M4 12h16M4 18.5h10"/><circle cx="18" cy="18" r="3"/><path d="m20.2 20.2 2 2"/>', wallet:'<path d="M4 7.5h15a1.5 1.5 0 0 1 1.5 1.5v8A2.5 2.5 0 0 1 18 19.5H6A2.5 2.5 0 0 1 3.5 17V6A2.5 2.5 0 0 1 6 3.5h11"/><path d="M16 13h4.5"/>', chart:'<path d="M4 19V9M10 19V5M16 19v-8M22 19H2"/>', plus:'<path d="M12 5v14M5 12h14"/>', arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>', chevron:'<path d="m9 18 6-6-6-6"/>', filter:'<path d="M4 6h16M7 12h10M10 18h4"/>', calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>', more:'<circle cx="5" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none"/>', menu:'<path d="M4 7h16M4 12h16M4 17h16"/>', alert:'<path d="M12 4 3 20h18L12 4Z"/><path d="M12 10v4M12 17h.01"/>', empty:'<path d="M5 4.5h14v15H5z"/><path d="M8 8h8M8 12h8M8 16h4"/>', close:'<path d="m6 6 12 12M18 6 6 18"/>' }; return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${p[name] || p.empty}</svg>` }
const amount = (n, currency = 'IRR') => `<span class="money" dir="ltr"><bdi>${new Intl.NumberFormat(state.lang === 'fa' ? 'fa-IR' : 'en-US').format(n)}</bdi> <bdi>${currency}</bdi></span>`
const date = (en, fa) => `<bdi dir="ltr">${state.lang === 'fa' ? fa : en}</bdi>`
const sheets = [
  { id:'PC-2401', title:{en:'October office supplies',fa:'ملزومات اداری مهرماه'}, status:'open', owner:{en:'You',fa:'شما'}, currency:'IRR', transactions:6, revision:1, current:12450000, submitted:0, approved:0, rejected:0, pending:0, stage:{manager:0,senior:0,finance:0}, created:['Oct 02, 2026','۱۱ مهر ۱۴۰۵'], submittedDate:['—','—'], completed:['—','—'], first:['Oct 03, 2026','۱۲ مهر ۱۴۰۵'], last:['Oct 14, 2026','۲۲ مهر ۱۴۰۵'] },
  { id:'PC-2398', title:{en:'Field visit — Q4',fa:'بازدید میدانی — فصل چهارم'}, status:'correctionStatus', owner:{en:'You',fa:'شما'}, currency:'IRR', transactions:12, revision:4, current:48600000, submitted:48600000, approved:46200000, rejected:2400000, pending:0, stage:{manager:46200000,senior:46200000,finance:0}, created:['Sep 28, 2026','۶ مهر ۱۴۰۵'], submittedDate:['Oct 11, 2026','۱۹ مهر ۱۴۰۵'], completed:['—','—'], first:['Sep 29, 2026','۷ مهر ۱۴۰۵'], last:['Oct 10, 2026','۱۸ مهر ۱۴۰۵'] },
  { id:'PC-2387', title:{en:'Team workshop',fa:'کارگاه تیمی'}, status:'finance', owner:{en:'You',fa:'شما'}, currency:'IRR', transactions:9, revision:3, current:32700000, submitted:32700000, approved:0, rejected:0, pending:32700000, stage:{manager:32700000,senior:32700000,finance:0}, created:['Sep 20, 2026','۲۹ شهریور ۱۴۰۵'], submittedDate:['Oct 05, 2026','۱۳ مهر ۱۴۰۵'], completed:['—','—'], first:['Sep 22, 2026','۳۱ شهریور ۱۴۰۵'], last:['Oct 03, 2026','۱۱ مهر ۱۴۰۵'] },
  { id:'PC-2375', title:{en:'September travel',fa:'سفرهای شهریور'}, status:'completedApproved', owner:{en:'You',fa:'شما'}, currency:'IRR', transactions:18, revision:5, current:71500000, submitted:71500000, approved:71500000, rejected:0, pending:0, stage:{manager:71500000,senior:71500000,finance:71500000}, created:['Sep 02, 2026','۱۱ شهریور ۱۴۰۵'], submittedDate:['Sep 20, 2026','۲۹ شهریور ۱۴۰۵'], completed:['Sep 29, 2026','۷ مهر ۱۴۰۵'], first:['Sep 03, 2026','۱۲ شهریور ۱۴۰۵'], last:['Sep 18, 2026','۲۷ شهریور ۱۴۰۵'] },
]
const accounts = { main:{id:'main', label:{en:'Main petty cash',fa:'تنخواه اصلی'}, currency:'IRR', balance:184250000}, travel:{id:'travel', label:{en:'Field travel',fa:'هزینه سفر میدانی'}, currency:'IRR', balance:92000000}, single:{id:'single', label:{en:'Default petty cash',fa:'تنخواه پیش‌فرض'}, currency:'IRR', balance:184250000} }
const statusLabel = (key) => ({open:t('open'),costCenter:t('costCenter'),senior:t('senior'),finance:t('finance'),completedApproved:t('completedApproved'),completedRejected:t('completedRejected'),correctionStatus:t('correctionStatus')}[key] || key)
const accountList = () => state.accountBranch === 'many' ? [accounts.main, accounts.travel] : state.accountBranch === 'one' ? [accounts.single] : []
function shell() { return `<div class="app-shell"><aside class="sidebar"><div class="brand"><img src="./assets/pettycash-mark.svg" alt=""/><span>${t('appName')}</span></div><nav class="sidebar__nav"><p class="sidebar__label">${t('workspace')}</p>${[['dashboard','dashboard','dashboard'],['sheets','sheets','sheets'],['reviewQueue','reviewQueue','review'],['accounts','accounts','wallet'],['reports','reports','chart']].map(([key,page,ico])=>`<button class="nav-item ${state.page===page?'is-active':''}" data-page="${page}">${icon(ico)}<span>${t(key)}</span>${page==='reviewQueue'?'<span class="nav-count">3</span>':''}</button>`).join('')}</nav><div class="sidebar__bottom"><button class="nav-item nav-item--muted">${icon('empty')}<span>${t('support')}</span></button><div class="user-card"><div class="avatar">ن</div><div><strong>${state.lang==='fa'?'نگار احمدی':'Negar Ahmadi'}</strong><span>${state.lang==='fa'?'خریدار':'Purchaser'}</span></div></div></div></aside><main class="main-stage"><header class="topbar"><button class="mobile-menu" data-action="open-menu">${icon('menu')}</button><div class="breadcrumbs"><span>${t('appName')}</span><span>/</span><strong>${state.page==='dashboard'?t('dashboard'):state.page==='sheets'?t('sheets'):state.mode==='edit'?t('editSheet'):t('createSheet')}</strong></div><div class="topbar__actions"><span class="role-pill">${t('purchaserView')}</span><div class="avatar avatar--small">ن</div></div><button class="mobile-close" data-action="close-menu">${icon('close')}</button></header><div class="content-wrap" id="content"></div></main></div>` }
function header(eyebrow,title,sub,actionText,actionPage){ return `<div class="page-header"><div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p class="page-subtitle">${sub}</p></div><div class="page-header__actions"><span class="date-chip">${icon('calendar')}${t('today')}</span>${actionText?`<button class="button button--primary" data-page="${actionPage}">${icon('plus')}${actionText}</button>`:''}</div></div>` }
function stateCard(kind){ const title=kind==='empty'?t('empty'):kind==='error'?t('errorTitle'):t('loading'); const body=kind==='empty'?t('emptyBody'):kind==='error'?t('errorBody'):t('loadingBody'); return `<div class="state-card state-card--${kind}"><div class="state-card__icon">${icon(kind==='error'?'alert':kind==='empty'?'empty':'sheets')}</div><h2>${title}</h2><p>${body}</p>${kind==='error'?`<button class="button button--secondary" data-action="retry">${t('retry')}</button>`:''}</div>` }
function dashboard(){ return `${header(t('overview'),t('dashboard'),t('dashboardSub'),t('newSheet'),'create')}<div class="scope-note"><strong>${t('purchaserView')}</strong><span>${t('creatorScope')} · ${t('creatorScopeBody')}</span></div><div class="metric-grid">${[['openSheets','2','openHint','sheets','accent'],['awaitingReview','2','awaitingHint','review','warning'],['correction','1','correctionHint','alert','danger'],['completed','1','completedHint','dashboard','neutral']].map(([label,value,hint,ico,tone])=>`<article class="metric-card metric-card--${tone}"><div class="metric-card__top"><span class="metric-card__icon">${icon(ico)}</span><span>${t(label)}</span></div><strong>${value}</strong><span class="metric-card__hint">${t(hint)}</span></article>`).join('')}</div><div class="dashboard-grid"><section class="panel panel--table"><div class="panel__header"><div><h2>${t('recent')}</h2><p>${t('recentBody')}</p></div><button class="text-button" data-page="sheets">${t('viewSheets')} ${icon('arrow')}</button></div>${table(sheets.slice(0,3),true)}</section><aside class="panel quick-panel"><div class="quick-links-title"><span>${icon('arrow')}</span><h2>${t('quickLinks')}</h2></div><button class="quick-link" data-page="sheets"><span><b>${t('continueDraft')}</b><small>${t('continueDraftBody')}</small></span>${icon('chevron')}</button><button class="quick-link" data-page="sheets"><span><b>${t('reviewReturned')}</b><small>${t('reviewReturnedBody')}</small></span>${icon('chevron')}</button><button class="button button--primary quick-link-button" data-page="create">${icon('plus')}${t('createNew')}</button></aside></div>` }
function status(status){ const tone=status==='correctionStatus'?'correction':status; return `<span class="status-chip status-chip--${tone}"><span class="status-dot"></span>${statusLabel(status)}</span>` }
function stageTotals(s){ return `<div class="stacked-values"><span>${t('manager')}: ${s.stage.manager?amount(s.stage.manager):t('noDate')}</span><span>${t('seniorShort')}: ${s.stage.senior?amount(s.stage.senior):t('noDate')}</span><span>${t('financeShort')}: ${s.stage.finance?amount(s.stage.finance):t('noDate')}</span></div>` }
function dates(s){ return `<div class="stacked-values dates"><span>${t('created')}: ${date(...s.created)}</span><span>${t('submittedAt')}: ${date(...s.submittedDate)}</span><span>${t('completedAt')}: ${date(...s.completed)}</span></div>` }
// Design prototype v2 — English Sheets List + in-context sheet workspace.
// All values and interactions below are LOCAL SYNTHETIC FIXTURES (not an API).
Object.assign(copy.en, {
  sheetsSub:'A clear view of your recorded amounts and the latest approval reached.',
  recordedAmount:'Recorded amount', latestApprovedAmount:'Latest approved amount',
  listTip:'Select a sheet to open its workspace. Your list stays exactly where you left it.',
  selectToOpen:'Open sheet details', overviewTab:'Overview', transactionsTab:'Transactions', historyTab:'Approvals',
  sheetOverview:'Sheet overview', currentStage:'Current stage', lastReview:'Latest completed approval',
  notYetApproved:'No approval yet', sheetWorkspace:'Sheet workspace', saved:'Saved in this prototype',
  closeWorkspace:'Close workspace', editDetails:'Edit sheet', correctTransactions:'Correct transactions',
  viewTransactions:'View transactions', addTransaction:'Add transaction', deleteSheet:'Delete sheet',
  transactionDescription:'Description', transactionAmount:'Amount (IRR)',
  accountInfo:'Account & currency', sheetTimeline:'Approval progress',
  sheetIntro:'Review totals, transactions, and approvals. Available actions depend on the current stage.',
  onlyRead:'Read-only at this stage', moreInfo:'All detailed stage totals are kept here, not in the list.',
  unsavedTitle:'You have unsaved changes',
  unsavedBody:'Leaving this sheet will discard the changes you have not saved.',
  keepEditing:'Keep editing', discardChanges:'Discard changes', saveChanges:'Save changes',
  saveFailed:'Please enter a sheet title before saving.',
  deleteTitle:'Delete this open sheet?', deleteBody:'This action cannot be undone in the real application. This prototype will only remove the mock sheet.',
  confirmDelete:'Delete mock sheet', deleteCancel:'Keep sheet',
  stageCostCenter:'Cost center manager', stageSenior:'Senior manager', stageFinance:'Finance',
  notStarted:'Not reached', awaitingDecision:'Awaiting decision', lastUpdated:'Updated',
  sheetId:'Sheet ID', sheetType:'Petty cash sheet', backToDetails:'Back to sheet',
  transactionEdit:'Transaction details', transactionCreate:'New transaction',
  transactionNote:'These are synthetic transaction examples; no real records are changed.',
  btnSave:'Save', infoBanner:'Design prototype · fictional data · no Nextcloud or API connection',
})
const prototypeState = {
  sheetId: params.get('sheet') || null,
  tab: 'overview',
  view: 'detail',
  editDraft: '',
  transactionDraft: {name:'',amount:''},
  transactionIndex: 0,
  dirty:false,
  confirm:null,
  filters:{status:'',currency:'',from:'',to:''},
  lastTrigger:null,
  listScroll:0,
  txnFixtures: {},
  toast: '',
}
const escapeHTML = v => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
const lastApproved = (s) => {
  // Last VALID completed review amount, not final-only financial approval.
  // The production source/API must determine revision validity. Here it is a fixture.
  if(s.status === 'open' || s.status === 'costCenter') return 0
  if(s.status === 'senior') return s.stage.manager || 0
  if(s.status === 'finance') return s.stage.senior || 0
  if(s.status === 'completedApproved' || s.status === 'completedRejected') return s.stage.finance || 0
  if(s.status === 'correctionStatus') return s.stage.senior || s.stage.manager || 0
  return 0
}
const getSheet = id => sheets.find(s=>s.id === id)
const getTransactions = s => {
  if(!prototypeState.txnFixtures[s.id]) {
    // Synthetic examples, generated from fixture totals, not accounting truth.
    const a=Math.floor(s.current * .44), b=Math.floor(s.current * .31)
    prototypeState.txnFixtures[s.id]=[
      {name:'Office materials and supplies',amount:a},
      {name:'Local travel and transport',amount:b},
      {name:'Other documented expenses',amount:s.current-a-b},
    ]
  }
  return prototypeState.txnFixtures[s.id]
}
const rowMarkup = s => `<article class="summary-row" data-open-sheet="${s.id}" aria-label="Open ${escapeHTML(s.title.en)}">
  <div class="summary-row__sheet"><span class="sheet-row__mark">${s.id.slice(-2)}</span><div><a href="?page=sheets&lang=en&theme=${state.theme}&sheet=${encodeURIComponent(s.id)}" data-sheet-link="${s.id}" class="summary-title">${escapeHTML(s.title.en)}</a><small>${s.id}</small></div></div>
  <div class="summary-row__status">${status(s.status)}</div>
  <div class="summary-row__tx" data-label="Transactions">${s.transactions}</div>
  <div class="summary-row__money" data-label="Recorded amount">${amount(s.current, s.currency)}</div>
  <div class="summary-row__money approved" data-label="Latest approved">${amount(lastApproved(s),s.currency)}</div>
  <div class="summary-row__arrow" aria-hidden="true">${icon('chevron')}</div>
</article>`
function table(rows, compact=false, purchaserOnly=false){ return `<div class="summary-table"><div class="summary-table__head"><span>${t('sheet')}</span><span>${t('status')}</span><span>${t('transactions')}</span><span>${t('recordedAmount')}</span><span>${t('latestApprovedAmount')}</span><span></span></div>${rows.length?rows.map(rowMarkup).join(''):`<div class="no-results">${t('empty')}</div>`}</div>` }
function sheetsPage(){
 const f=prototypeState.filters
 const available=sheets.filter(s => (!f.status || s.status===f.status) && (!f.currency || s.currency===f.currency) && (!f.from || s.created[0] && new Date(s.created[0]) >= new Date(f.from)) && (!f.to || s.created[0] && new Date(s.created[0]) <= new Date(f.to)))
 return `${header(t('workspace'),t('sheets'),t('sheetsSub'),t('newSheet'),'create')}
 <div class="prototype-hint">${icon('empty')}${t('infoBanner')}</div>
 <section class="filter-panel v2-filter"><div class="filter-panel__title">${icon('filter')}<strong>${t('filters')}</strong><span>${available.length} sheets · Purchaser</span></div>
 <div class="filter-panel__fields">
 <label><span>${t('statusFilter')}</span><select id="f-status"><option value="">${t('allStatuses')}</option>${['open','correctionStatus','costCenter','senior','finance','completedApproved'].map(k=>`<option value="${k}" ${f.status===k?'selected':''}>${statusLabel(k)}</option>`).join('')}</select></label>
 <label><span>${t('currencyFilter')}</span><select id="f-currency"><option value="">${t('allCurrencies')}</option><option value="IRR" ${f.currency==='IRR'?'selected':''}>IRR</option></select></label>
 <label><span>${t('from')}</span><input id="f-from" type="date" value="${f.from}"></label><label><span>${t('to')}</span><input id="f-to" type="date" value="${f.to}"></label>
 <div class="filter-actions"><button class="button button--primary" id="apply-filter">${t('apply')}</button><button class="text-button" id="reset-filter">${t('reset')}</button></div></div></section>
 <section class="panel panel--table v2-sheet-panel"><div class="panel__header"><div><h2>My sheets</h2><p>${t('purchaserList')}</p></div><span class="section-count">${available.length}</span></div>
 ${table(available,false,true)}<p class="list-footer">${t('listTip')}</p></section>`
}
const stepDescriptor = (s) => [
 {key:'manager',title:t('stageCostCenter')},
 {key:'senior',title:t('stageSenior')},
 {key:'finance',title:t('stageFinance')},
].map((step,i) => {
 const amountVal=s.stage[step.key]
 let label, tone
 if (amountVal>0){ label=amount(amountVal,s.currency);tone='done' }
 else if((s.status==='costCenter'&&i===0)||(s.status==='senior'&&i===1)||(s.status==='finance'&&i===2)){label=t('awaitingDecision');tone='pending'}
 else{ label=t('notStarted');tone='muted' }
 return `<div class="approval-step approval-step--${tone}"><span class="step-icon">${amountVal>0?'✓':i+1}</span><div><strong>${step.title}</strong><small>${label}</small></div></div>`
}).join('')
function transactionList(s){ const canAdd=s.status==='open'; const canCorrect=s.status==='correctionStatus'; return `<div class="detail-section-heading"><div><h3>Transactions</h3><p class="muted">${t('transactionNote')}</p></div>${canAdd?`<button class="button button--primary" data-modal-action="add-transaction">${icon('plus')}${t('addTransaction')}</button>`:''}</div><div class="transaction-list">${getTransactions(s).map((x,i)=>`<button class="transaction-item" data-modal-action="transaction" data-txn-index="${i}"><span><strong>${escapeHTML(x.name)}</strong><small>Expense ${i+1} · ${canCorrect?'Correction possible':''}</small></span><b>${amount(x.amount,s.currency)}</b>${icon('chevron')}</button>`).join('')}</div>` }
function detailContents(s){
 const statusIsEditable=s.status==='open', canCorrect=s.status==='correctionStatus'
 return `<div class="workspace-overview">
 <div class="workspace-headline"><div><span class="eyebrow">${t('sheetType')} · ${s.id}</span><h2>${escapeHTML(s.title.en)}</h2><span>${status(s.status)}</span></div><div class="workspace-headline__actions">${statusIsEditable?`<button class="button button--secondary" data-modal-action="edit">${icon('sheets')} Edit sheet</button>`:''}${canCorrect?`<button class="button button--primary" data-modal-action="correct">Correct transactions ${icon('arrow')}</button>`:''}${!statusIsEditable&&!canCorrect?`<span class="readonly-notice">${icon('empty')}${t('onlyRead')}</span>`:''}</div></div>
 <div class="workspace-metrics"><article class="workspace-metric"><span>${t('recordedAmount')}</span><strong>${amount(s.current,s.currency)}</strong><small>Current total entered by purchaser</small></article><article class="workspace-metric workspace-metric--green"><span>${t('latestApprovedAmount')}</span><strong>${amount(lastApproved(s),s.currency)}</strong><small>${lastApproved(s)===0?t('notYetApproved'):'Latest valid completed review in this demo'}</small></article><article class="workspace-metric"><span>${t('transactions')}</span><strong>${s.transactions}</strong><small>${t('lastUpdated')}: ${date(...s.last)}</small></article></div>
 <div class="workspace-tabs" role="tablist" aria-label="Sheet workspace sections">${[['overview','Overview'],['transactions','Transactions'],['history','Approvals']].map(([k,v])=>`<button role="tab" aria-selected="${prototypeState.tab===k}" class="workspace-tab ${prototypeState.tab===k?'is-selected':''}" data-modal-tab="${k}">${v}</button>`).join('')}</div>
 ${prototypeState.tab==='overview'?`<div class="workspace-two-col"><section class="workspace-card"><h3>Sheet information</h3><dl class="details-list"><div><dt>Sheet ID</dt><dd>${s.id}</dd></div><div><dt>Current stage</dt><dd>${status(s.status)}</dd></div><div><dt>Created</dt><dd>${date(...s.created)}</dd></div><div><dt>Account currency</dt><dd>${s.currency}</dd></div><div><dt>Submitted amount (detail only)</dt><dd>${amount(s.submitted,s.currency)}</dd></div></dl></section><section class="workspace-card"><h3>Latest approval trail</h3>${stepDescriptor(s)}</section></div>`:prototypeState.tab==='transactions'?transactionList(s):`<section class="workspace-card"><h3>Approval progress</h3><p class="muted">Stage amounts belong in sheet details, not the list.</p>${stepDescriptor(s)}</section>`}
 ${statusIsEditable?`<div class="workspace-danger-zone"><span>Sheet management</span><button class="text-action text-action--danger" data-modal-action="delete">Delete open sheet</button></div>`:''}
 </div>`
}
function editContents(s){return `<div class="workspace-form-screen"><button class="workspace-back" data-modal-action="back">${icon('chevron')} ${t('backToDetails')}</button><h2>Edit sheet</h2><p class="muted">Only existing allowed fields are shown in this design example.</p><form id="modal-edit-form" class="workspace-edit-form"><label class="field"><span>Sheet title <em>*</em></span><input id="modal-title" value="${escapeHTML(prototypeState.editDraft)}" required autocomplete="off" aria-describedby="modal-title-hint"/><small id="modal-title-hint">Changes are local to this prototype.</small></label><div class="readonly-summary"><span>Currency</span><b>IRR</b><span>Sheet ID</span><b>${s.id}</b></div><div class="edit-footer"><button class="button button--secondary" type="button" data-modal-action="back">Cancel</button><button class="button button--primary" type="submit">Save changes</button></div></form></div>`}
function transactionContents(s){const list=getTransactions(s); const x=prototypeState.view==='transaction-new'?{name:'',amount:''}:list[prototypeState.transactionIndex]; const editable=s.status==='open'||s.status==='correctionStatus'; const newMode=prototypeState.view==='transaction-new';return `<div class="workspace-form-screen"><button class="workspace-back" data-modal-action="back-transactions">${icon('chevron')} Back to transactions</button><h2>${newMode?'Add transaction':'Transaction details'}</h2><p class="muted">${t('transactionNote')}</p><form id="modal-transaction-form" class="workspace-edit-form"><label class="field"><span>Description</span><input id="modal-txn-name" value="${escapeHTML(prototypeState.transactionDraft.name)}" ${editable?'':'readonly'} required/></label><label class="field"><span>Amount (IRR)</span><input id="modal-txn-amount" type="number" min="1" step="1" value="${escapeHTML(prototypeState.transactionDraft.amount)}" ${editable?'':'readonly'} required/></label>${editable?`<div class="edit-footer"><button type="button" data-modal-action="back-transactions" class="button button--secondary">Cancel</button><button class="button button--primary" type="submit">Save transaction</button></div>`:`<p class="readonly-notice">Read-only: changes are not permitted at this stage.</p>`}</form></div>`}
function renderModal(){
 let root=document.getElementById('workspace-root');if(!root){root=document.createElement('div');root.id='workspace-root';document.body.append(root)}
 const s=getSheet(prototypeState.sheetId)
 if(!s){root.innerHTML='';document.body.classList.remove('workspace-open');return}
 document.body.classList.add('workspace-open')
 const editing=prototypeState.view==='edit', transaction=prototypeState.view.startsWith('transaction')
 root.innerHTML=`<div class="workspace-backdrop" data-modal-action="backdrop"><section class="sheet-workspace" role="dialog" aria-modal="true" aria-labelledby="workspace-title" tabindex="-1">
 <header class="workspace-topbar"><div class="workspace-identity"><span class="workspace-icon">${icon('sheets')}</span><div><span>MY SHEETS / ${s.id}</span><h2 id="workspace-title">${editing?'Edit sheet':transaction?'Transaction':t('sheetWorkspace')}</h2></div></div><div class="workspace-topbar__right"><span class="readonly-notice mobile-hidden">${prototypeState.dirty?'● Unsaved changes':'Preview workspace'}</span><button class="icon-button workspace-close" data-modal-action="close" aria-label="Close workspace">${icon('close')}</button></div></header>
 <div class="workspace-scroll">${editing?editContents(s):transaction?transactionContents(s):detailContents(s)}</div>
 <footer class="workspace-footer"><span>${prototypeState.dirty?'Unsaved changes':'Prototype only — nothing is sent to a server.'}</span><button type="button" class="button button--secondary" data-modal-action="close">Close & return to sheets</button></footer>
 </section></div>${prototypeState.confirm?confirmMarkup():''}`
 const dialog=root.querySelector('.sheet-workspace');dialog?.focus({preventScroll:true})
}
function confirmMarkup(){const del=prototypeState.confirm==='delete';return `<div class="confirm-backdrop"><section role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-description" class="confirm-card" tabindex="-1"><span class="confirm-symbol">${icon('alert')}</span><h2 id="confirm-title">${del?t('deleteTitle'):t('unsavedTitle')}</h2><p id="confirm-description">${del?t('deleteBody'):t('unsavedBody')}</p><div class="confirm-actions"><button class="button button--secondary" data-confirm="stay">${del?t('deleteCancel'):t('keepEditing')}</button>${!del?`<button class="button button--secondary" data-confirm="discard">${t('discardChanges')}</button>`:''}<button class="button ${del?'button--destructive':'button--primary'}" data-confirm="${del?'delete':'save'}">${del?t('confirmDelete'):t('saveChanges')}</button></div></section></div>`}
function createPage(){ const list=accountList(); const selected=list.find(a=>a.id===state.selectedAccount); const editing=state.mode==='edit'; const canSubmit=Boolean(state.formTitle.trim()) && (list.length===0 || Boolean(selected)); return `${header(t('workspace'),editing?t('editSheet'):t('createSheet'),editing?t('editSub'):t('createSub'),t('viewSheets'),'sheets')}<div class="form-layout"><section class="panel form-panel"><div class="panel__header"><div><h2>${t('details')}</h2><p>${editing?`${t('editSheet')} · <bdi dir="ltr">PC-2401</bdi>`:t('createSub')}</p></div><span class="step-badge">${editing?'PC-2401':'1 / 1'}</span></div>${state.validation?`<div class="form-alert"><span>${icon('alert')}</span><div><strong>${t('validationTitle')}</strong><p>${t('validationBody')}</p></div></div>`:''}<form id="sheet-form"><div class="form-grid"><label class="field field--wide"><span>${t('title')} <em>*</em></span><input id="sheet-title" value="${state.formTitle}" placeholder="${t('titlePlaceholder')}" /></label><label class="field"><span>${t('account')}</span>${list.length===0?`<div class="empty-account"><strong>${t('noAccounts')}</strong><small>${t('noAccountsBody')}</small></div>`:`<select id="account-select"><option value="">${t('selectAccount')}</option>${list.map(a=>`<option value="${a.id}" ${a.id===state.selectedAccount?'selected':''}>${a.label[state.lang]} · ${a.currency}</option>`).join('')}</select>`}<small class="field-hint">${list.length===0?t('noAccountsBody'):list.length===1?t('oneAccount'):t('manyAccounts')}</small></label><label class="field"><span>${t('inheritedCurrency')}</span><div class="readonly-field"><strong>${selected?selected.currency:'—'}</strong><span>${selected?icon('sheets'):''}</span></div><small class="field-hint">${t('inheritedHint')}</small></label></div>${selected?`<div class="account-summary"><span class="account-summary__icon">${icon('wallet')}</span><div><span>${t('accountBalance')}</span><strong>${amount(selected.balance,selected.currency)}</strong></div><span class="account-summary__badge">${selected.currency}</span></div>`:`<div class="account-summary account-summary--empty"><span class="account-summary__icon">${icon('wallet')}</span><div><span>${t('accountBalance')}</span><strong>${t('noBalance')}</strong></div></div>`}<div class="form-actions"><button type="button" class="button button--secondary" data-page="sheets">${t('cancel')}</button><button type="submit" class="button button--primary" ${canSubmit?'':'disabled'}>${editing?t('update'):t('create')} ${icon('arrow')}</button></div></form></section><aside class="side-note"><div class="side-note__number">01</div><h3>${editing?t('editSheet'):t('createSheet')}</h3><p>${editing?t('editSub'):t('createSub')}</p><div class="side-note__rule"></div><span>${list.length===0?t('noAccounts'):list.length===1?t('oneAccount'):t('manyAccounts')}</span></aside></div>` }

function render(){
 document.documentElement.lang=state.lang
 document.documentElement.dir=state.lang==='fa'?'rtl':'ltr'
 document.documentElement.dataset.theme=state.theme
 app.innerHTML=shell()
 document.querySelector('#content').innerHTML=state.page==='dashboard'?dashboard():state.page==='sheets'?sheetsPage():createPage()
 bind()
 if(prototypeState.sheetId && state.page==='sheets')renderModal()
 else{prototypeState.sheetId=null;renderModal()}
}
function makeURL(sheetId=prototypeState.sheetId){const q=new URLSearchParams({page:state.page,lang:state.lang,theme:state.theme});if(state.page==='create'){q.set('mode',state.mode);q.set('accounts',state.accountBranch)}if(sheetId)q.set('sheet',sheetId);return `${location.pathname}?${q}`}
function url(){ history.replaceState({},'',makeURL()) }
function openSheet(id,trigger=null,push=true){
 if(!getSheet(id))return
 prototypeState.lastTrigger=trigger
 prototypeState.sheetId=id
 prototypeState.view='detail';prototypeState.tab='overview';prototypeState.dirty=false;prototypeState.confirm=null
 if(push)history.pushState({sheetModal:true,id},'',makeURL(id))
 renderModal()
}
function closeNow(){
 const root=document.getElementById('workspace-root');root?.replaceChildren()
 document.body.classList.remove('workspace-open');prototypeState.sheetId=null;prototypeState.dirty=false;prototypeState.confirm=null;prototypeState.view='detail'
 if(history.state?.sheetModal) history.back()
 else history.replaceState({},'',makeURL(null))
 setTimeout(()=>{
  const target=prototypeState.lastTrigger?.isConnected ? prototypeState.lastTrigger : document.querySelector('[data-sheet-link]')
  target?.focus({preventScroll:true})
 },0)
}
function requestClose(){if(prototypeState.dirty){prototypeState.confirm='unsaved';renderModal();document.querySelector('.confirm-card')?.focus();return}closeNow()}
function requestModalBack(){if(prototypeState.dirty){prototypeState.confirm='unsaved-back';renderModal();document.querySelector('.confirm-card')?.focus();return}prototypeState.view='detail';renderModal()}
function saveDraft(){
 const s=getSheet(prototypeState.sheetId);if(!s)return false
 if(prototypeState.view==='edit'){
  const value=prototypeState.editDraft.trim();if(!value){document.querySelector('#modal-title')?.focus();return false}
  s.title.en=value
 }else if(prototypeState.view.startsWith('transaction')){
  const draft=prototypeState.transactionDraft;const value=draft.name.trim();const money=Number(draft.amount)
  if(!value || !(money>0)){document.querySelector('#modal-txn-name')?.focus();return false}
  const rows=getTransactions(s)
  if(prototypeState.view==='transaction-new'){rows.push({name:value,amount:money});s.transactions++ ;s.current+=money}
  else {const original=rows[prototypeState.transactionIndex];s.current+=money-original.amount;rows[prototypeState.transactionIndex]={name:value,amount:money}}
 }
 prototypeState.dirty=false;prototypeState.confirm=null;prototypeState.view='detail';prototypeState.tab='overview'
 // On a save, return to detail (unless this was an unsaved-close confirmation).
 const previousScroll=window.scrollY
 render();window.scrollTo(0,previousScroll);return true
}
function openTransaction(s,index,mode){
 prototypeState.transactionIndex=index
 prototypeState.transactionDraft= mode==='new'?{name:'',amount:''}:{name:getTransactions(s)[index].name,amount:String(getTransactions(s)[index].amount)}
 prototypeState.view=mode==='new'?'transaction-new':'transaction';prototypeState.dirty=false
 renderModal()
}
function bind(){
 document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>{if(prototypeState.sheetId)return;state.page=el.dataset.page;url();render()}))
 document.querySelectorAll('[data-action="open-menu"]').forEach(el=>el.addEventListener('click',()=>document.body.classList.add('menu-open')))
 document.querySelectorAll('[data-action="close-menu"]').forEach(el=>el.addEventListener('click',()=>document.body.classList.remove('menu-open')))
 document.querySelector('#apply-filter')?.addEventListener('click',()=>{
  const f=prototypeState.filters;f.status=document.getElementById('f-status').value;f.currency=document.getElementById('f-currency').value;f.from=document.getElementById('f-from').value;f.to=document.getElementById('f-to').value
  document.querySelector('#content').innerHTML=sheetsPage();bind()
 })
 document.querySelector('#reset-filter')?.addEventListener('click',()=>{prototypeState.filters={status:'',currency:'',from:'',to:''};document.querySelector('#content').innerHTML=sheetsPage();bind()})
 document.querySelectorAll('[data-sheet-link]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();openSheet(el.dataset.sheetLink,el)}))
 document.querySelectorAll('[data-open-sheet]').forEach(el=>el.addEventListener('click',e=>{if(e.target.closest('[data-sheet-link]'))return;openSheet(el.dataset.openSheet,el.querySelector('[data-sheet-link]'))}))
 document.querySelector('#account-select')?.addEventListener('change',e=>{state.selectedAccount=e.target.value;render()})
 document.querySelector('#sheet-title')?.addEventListener('input',e=>{state.formTitle=e.target.value;document.querySelector('#sheet-form button[type="submit"]')?.toggleAttribute('disabled', !state.formTitle.trim() || (accountList().length > 0 && !state.selectedAccount))})
 document.querySelector('#sheet-form')?.addEventListener('submit',e=>{e.preventDefault();state.validation=!state.formTitle.trim() || (accountList().length > 0 && !state.selectedAccount);if(!state.validation)state.page='sheets';url();render()})
}
document.addEventListener('click',e=>{
 const conf=e.target.closest('[data-confirm]')
 if(conf){
  const action=conf.dataset.confirm
  if(action==='stay'){prototypeState.confirm=null;renderModal();return}
  if(action==='delete') {const i=sheets.findIndex(s=>s.id===prototypeState.sheetId);if(i!==-1 && sheets[i].status==='open'){sheets.splice(i,1);closeNow();render()}return}
  if(action==='discard') {const wasBack=prototypeState.confirm==='unsaved-back';prototypeState.dirty=false;prototypeState.confirm=null;if(wasBack){prototypeState.view='detail';prototypeState.tab='transactions';renderModal()}else closeNow();return}
  if(action==='save'){const wasBack=prototypeState.confirm==='unsaved-back';if(saveDraft()){if(!wasBack)closeNow()}return}
 }
 const tab=e.target.closest('[data-modal-tab]')
 if(tab){prototypeState.tab=tab.dataset.modalTab;renderModal();return}
 const act=e.target.closest('[data-modal-action]')
 if(!act)return
 const a=act.dataset.modalAction;const s=getSheet(prototypeState.sheetId)
 if(a==='backdrop'){if(e.target===act)requestClose();return}
 if(a==='close'){requestClose();return}
 if(!s)return
 if(a==='edit'&&s.status==='open'){prototypeState.editDraft=s.title.en;prototypeState.view='edit';prototypeState.dirty=false;renderModal()}
 if(a==='correct'&&s.status==='correctionStatus'){prototypeState.tab='transactions';renderModal()}
 if(a==='back'){requestModalBack()}
 if(a==='back-transactions'){if(prototypeState.dirty){prototypeState.confirm='unsaved-back';renderModal()}else{prototypeState.view='detail';prototypeState.tab='transactions';renderModal()}}
 if(a==='delete'&&s.status==='open'){prototypeState.confirm='delete';renderModal();document.querySelector('.confirm-card')?.focus()}
 if(a==='transaction'){openTransaction(s,Number(act.dataset.txnIndex),'existing')}
 if(a==='add-transaction'&&s.status==='open'){openTransaction(s,0,'new')}
})
document.addEventListener('input',e=>{
 const s=getSheet(prototypeState.sheetId)
 if(!s)return
 if(e.target.id==='modal-title'){prototypeState.editDraft=e.target.value;prototypeState.dirty=prototypeState.editDraft!==s.title.en}
 if(e.target.id==='modal-txn-name'){prototypeState.transactionDraft.name=e.target.value;prototypeState.dirty=true}
 if(e.target.id==='modal-txn-amount'){prototypeState.transactionDraft.amount=e.target.value;prototypeState.dirty=true}
 const note=document.querySelector('.workspace-footer > span');if(note)note.textContent=prototypeState.dirty?'Unsaved changes':'Prototype only — nothing is sent to a server.'
})
document.addEventListener('submit',e=>{
 if(e.target.id!=='modal-edit-form' && e.target.id!=='modal-transaction-form')return
 e.preventDefault();saveDraft()
})
document.addEventListener('keydown',e=>{
 if(!prototypeState.sheetId)return
 if(e.key==='Escape') {e.preventDefault();if(prototypeState.confirm){prototypeState.confirm=null;renderModal()}else requestClose();return}
 if(e.key==='Tab'){
  const dialog=document.querySelector(prototypeState.confirm?'.confirm-card':'.sheet-workspace')
  if(!dialog)return
  const nodes=[...dialog.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href]')].filter(el=>el.getClientRects().length)
  if(!nodes.length)return
  const first=nodes[0],last=nodes[nodes.length-1]
  if(e.shiftKey && (document.activeElement===first||document.activeElement===dialog)){e.preventDefault();last.focus()}
  else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus()}
 }
})
window.addEventListener('popstate',()=>{
 const target=new URLSearchParams(location.search).get('sheet')
 if(prototypeState.dirty && prototypeState.sheetId && target!==prototypeState.sheetId){
  history.pushState({sheetModal:true,id:prototypeState.sheetId},'',makeURL(prototypeState.sheetId))
  prototypeState.confirm='unsaved';renderModal();return
 }
 prototypeState.sheetId=target && getSheet(target)?target:null
 prototypeState.dirty=false;prototypeState.confirm=null;prototypeState.view='detail';prototypeState.tab='overview'
 renderModal()
})
render()
