# Pettycash UI design prototype

This is a review-only, static frontend prototype for the existing Pettycash workflows:

1. Dashboard
2. Sheets List
3. Create/Edit Sheet

It is not production app code. It uses synthetic records only and does not connect to Nextcloud, an API, or any financial system. The current refinement focuses exclusively on the English LTR purchaser Sheets List. Existing Persian/RTL files and prior exports remain preserved. The Pettycash source repository remains preserved separately at `../pettycash-source`; this refinement changes only the prototype workspace.

## Run locally

```bash
npm start
```

Open `http://localhost:3000`.

## Review the approved design set

The final exports are clean product surfaces. They do not include the earlier prototype debugging strip, `UI prototype` labels, workspace/account mock controls, or custom locale/theme controls. Nextcloud owns locale and theme in the real product; query parameters are used only to make static review variants easy to open.

Useful variants:

- `/?page=dashboard&lang=en&theme=light`
- `/?page=sheets&lang=en&theme=dark`
- `/?page=create&lang=en&theme=light&accounts=many`
- `/?page=create&mode=edit&lang=en&theme=light&accounts=one`
- `/?page=sheets&lang=en&theme=dark`

The English purchaser Sheets List uses the existing status/currency/date-from/date-to filters, omits Creator from the purchaser-only surface, retains financial/audit-facing columns, and gates actions by lifecycle status. Returned rows use Correct; finance-review and completed rows are View-only. Other pages remain available in the runnable prototype, while Persian/RTL files are preserved but not part of this refinement pass.

## Deliverables

- `index.html`, `styles.css`, `app.js`: portable static source
- `assets/pettycash-mark.svg`: synthetic mark; no Budget assets are copied
- `docs/design-components-tokens.md`: compact component and token sheet
- `CHANGELOG.md`: refinement record and unresolved behavior assumptions
- `exports/`: existing English/Persian desktop/mobile PNGs plus updated English Sheets List light/dark desktop/mobile PNGs
- `pettycash-ui-prototype.zip`: portable bundle
