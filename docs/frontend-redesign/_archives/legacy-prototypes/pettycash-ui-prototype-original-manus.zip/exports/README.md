# Pettycash final design exports

The current update adds the English LTR purchaser Sheets List exports in light and dark desktop/mobile themes. The Creator column is omitted from this purchaser-scoped surface. Open rows expose View/Edit/Delete, Returned rows expose View/Correct, and Finance-review and Completed rows are View-only.

The prior Persian/RTL exports remain in this folder unchanged and are not part of this refinement pass.

Desktop exports use a 1440px viewport. Mobile exports use the requested 390px viewport and reflow the same financial information into labelled cards.

The complete runnable/editable source is one directory up: `../index.html`, `../styles.css`, and `../app.js`. Run `npm start` from the project root.
